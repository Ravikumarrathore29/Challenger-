﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class ChallengePage : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LogInPage.aspx");
        }
        if (Session["UserName"] != null)
        {
            //Label2.Text = Session["UserName"].ToString();
            SqlDataAdapter sda = new SqlDataAdapter("Select UserName , Role , Registeremail from Login where Registeremail = SomeOne@gmail.com ", conn);
            DataTable d = new DataTable();
            sda.Fill(d);
            Label1.Text = d.Rows[0]["Role"].ToString();
            Label2.Text = d.Rows[0]["UserName"].ToString();
            Label3.Text = d.Rows[0]["Registeremail"].ToString();
        }
        conn.Open();
        SqlCommand cmd = new SqlCommand("Select ChallengeCode , Start_Date , End_Date, Discription from CHALLENGE  ", conn);
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        Repeater1.DataSource = ds;
        Repeater1.DataBind();
        conn.Close();

    }
    protected void LogOutButton_Click(object sender, EventArgs e)
    {
        Session.Clear();

        Response.Redirect("http://localhost:51035/LogInPage.aspx");
    }
}