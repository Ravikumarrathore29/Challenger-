﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;


public partial class AdminPage : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LogInPage.aspx");
        }


        if (Session["UserName"] != null)
        {
            //Label2.Text = Session["UserName"].ToString();

            SqlDataAdapter sda = new SqlDataAdapter("Select UserName , Role , Registeremail from Login where Registeremail ='" + Session["UserName"].ToString() + "' ", conn);
            DataTable d = new DataTable();
            sda.Fill(d);
            Label1.Text = d.Rows[0]["Role"].ToString();
            Label2.Text = d.Rows[0]["UserName"].ToString();
            Label3.Text = d.Rows[0]["Registeremail"].ToString();

        }

        if (!Page.IsPostBack)
        {

            string comd = "SELECT * FROM Login WHERE Role LIKE '%Challenger%' ";
            SqlDataAdapter adpt = new SqlDataAdapter(comd, conn);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataBind();
            DropDownList1.DataTextField = "Role";
            DropDownList1.DataValueField = "Role";
            DropDownList1.DataBind();
        }
    }
    protected void LogOutButton_Click(object sender, EventArgs e)
    {
        Session.Clear();

        Response.Redirect("http://localhost:51035/LogInPage.aspx");
    }
   
    protected void Button_SubmitClick(object sender, EventArgs e)
    {

        DateTime StartDateValue = DateTime.Parse(TxtStartDate.Value);
        DateTime EndDateValue = DateTime.Parse(TxtEndDate.Value);
        conn.Open();
        SqlCommand cmd = new SqlCommand("SP_CHALLENGE", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = conn;
        cmd.Parameters.AddWithValue("@Cordinator", DropDownList1.SelectedValue);
        cmd.Parameters.AddWithValue("@Start_Date", StartDateValue);
        cmd.Parameters.AddWithValue("@End_Date", EndDateValue);
        cmd.Parameters.AddWithValue("@Discription", TextAddress.Value);
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        
        conn.Close();
        DropDownList1.SelectedValue = "";
        TxtStartDate.Value = "";
        TxtEndDate.Value = "";
        TextAddress.Value = "";
    }
  

}