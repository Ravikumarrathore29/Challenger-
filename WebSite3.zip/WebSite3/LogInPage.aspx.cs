﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;




// when login page will run on browser page will get connected to sql server through sql connection 
public partial class LogInPage : System.Web.UI.Page
{ 
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString);
    string str, UserName, Password;
    SqlCommand com;
    SqlDataAdapter sqlda;
    DataTable dt;
    int RowCount;
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    // for login user 
    protected void LogInButton_Click(object sender, EventArgs e)
    {
        
        conn.Open();
        str = "Select * from Login";
        com = new SqlCommand(str);
        sqlda = new SqlDataAdapter(com.CommandText, conn);
        dt = new DataTable();
        sqlda.Fill(dt);
        RowCount = dt.Rows.Count;
        for (int i = 0; i < RowCount; i++)
        {
            UserName = dt.Rows[i]["Registeremail"].ToString();
            Password = dt.Rows[i]["Registerpassword"].ToString();
            if (UserName == TxtLoginusername.Text && Password == TxtLoginpassword.Text)
            { // user will get its userprofile page according to he was registered 
                Session["UserName"] = UserName;
                if (dt.Rows[i]["PreFix"].ToString() == "Challenge")
                    Response.Redirect("http://localhost:51035/ChallengePage.aspx");
                else if (dt.Rows[i]["PreFix"].ToString() == "Member")
                    Response.Redirect("http://localhost:51035/MemberPage.aspx");
                else if (dt.Rows[i]["PreFix"].ToString() == "Admin")
                    Response.Redirect("http://localhost:51035/AdminPage.aspx");
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Popup", "showdialog1('Warning!','Invalid Credentials.');", true);
            }
        }
        // textbox get empty after login
        TxtLoginusername.Text = TxtLoginpassword.Text = string.Empty;
    }



    // for registration of user
    protected void RegisterButton_Click(object sender, EventArgs e)
    {
        int length = FileUpload1.PostedFile.ContentLength;
        byte[] ImageFile = new byte[length];

        FileUpload1.PostedFile.InputStream.Read(ImageFile, 0, length);
        conn.Open();

        // This will give unique user id to each user
        string prefix = string.Empty;
        string query = string.Empty;
        prefix = DropDownList1.SelectedValue;
        SqlCommand cmd = new SqlCommand("INSERT INTO LOGIN (PreFix , UserName  , Registeremail, Registerpassword ,  image ) VALUES ('" + prefix + "' , @UserName , @Registeremail, @Registerpassword, @image)", conn);
        cmd.Connection = conn;
        cmd.Parameters.AddWithValue("@PreFix", prefix);
        cmd.Parameters.AddWithValue("@UserName", TxtRegisterusername.Text);
        cmd.Parameters.AddWithValue("@Registeremail", TxtResgisteremail.Text);
        cmd.Parameters.AddWithValue("@Registerpassword", TxtRegisterpassword.Text);
        cmd.Parameters.AddWithValue("@image", ImageFile);
        ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Popup", "showdialog1('Message!','You are Succesfully register.');", true);
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        conn.Close();

        TxtRegisterusername.Text = TxtResgisteremail.Text = TxtRegisterpassword.Text = TxtConfirmPassword.Text = string.Empty;
    }



    protected void ForgetButton_Click(object sender, EventArgs e)
    {
    }

}